# Inventory-Management

Maintain a systematic record of inventory: This System can be used to store the details of the inventory such as
category, products , supplier and Invoices.
Stock maintenance: Stock is maintained up-to-date by calculating the remaining stocks

Proper and timely order fulfillment and updating the inventory based on the sales details. Ensuring sufficient stock: An
email alert is implemented to maintain the availability of stocks whenever and wherever required in enough quantity.

Inventory Accuracy: This inventory management system helps organize and streamline inventory placing and acquisition of
stocks for better fulfillment.

Better user services: All of the above help boost user service practices

Functionalities -
Register.
Login using the Jwt token.
The Selling Price of the products are generated based on the discount percentage we give to the Maximum Retail Price.
The customer receives an email with Purchase Details when a purchase is done.
The Bill Invoice for the customers for the purchase they made is rendered as PDF.
The Stock Quantity in the Stocks are updated when a sale is made.
An email is send to the company's mail as an alert when the stock quantity goes low beyond a certain value.
The company receives an email with Order Details when an Order is placed from the Supplier.
The order invoice from supplier is rendered as PDF.
The Stock Quantity in the Supplier Stocks are updated when an Order is Placed. 
